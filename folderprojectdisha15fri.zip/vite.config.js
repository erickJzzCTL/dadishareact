// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Remove the alias for swiper
  // resolve: {
  //   alias: {
  //     'swiper': 'swiper/swiper-bundle.esm.js',
  //   },
  // },
});